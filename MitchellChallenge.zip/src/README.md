Description of what Vehicle.java does:
	Vehicle.java is responsible for creating the characteristics for each vehicle. For
the purpose of this assignment, I ensured that each vehicle had four characteristics:
the ID (id), year it was made (year), the make, and lastly the model. I also ensured
that each of these instance variables were private. In Vehicle.java, I made the getter
and setter methods for each vehicle because it would allow for me to obtain or set the
values of id, year, make, and model. The id and year were initialized to zero, while
the make and model were initialized to null.

Description of VehicleData.java
	VehicleData.java is the main driver of the program. Here is where we control what
information will be entered into the database, what gets deleted, what changes etc. I
created a list of Vehicle objects because lists have an easier runtime in terms of 
getting data, however, I knew that I compensated the insertion of data as that would be
slower. I made a method called createVehicle, which was responsible for adding the 
vehicle to the database. Next, I had a method getById, which would filter all the 
vehicles based off their ID and print them to an external file. This would allow the 
user to not deal with two much code and just run the function, and allow the user to 
read data easier. Next, I had a method called getData() which wrote all of the vehicles
in the database to a file of the user's choice. If either the make or model were null,
I ensured that null was written for those respective columns. My next method was 
updateId, which was required if the user needed to change the ID of the vehicle. The 
next couple of methods'primary purpose was this: either update the year, make, or model. 
This is important because data can always be inserted wrong. Lastly, I made a method 
that would delete a vehicle that was passed in. In the optional part of the assignment,
I filtered all vehicles based off the year that they were made from. In the example
provided, they had wanted all cars from 1950-2000 made cars, however, using my 
implementation, we can access all vehicles from any range of years. If the given
start year was greater than end year, then nothing will be written to the file.

Testing:
	I used JUnit as a way to test my program's accuracy.
	
In-memory persistence:
	I used to write all my data to a file to ensure that we had a way to keep track of
all the vehicles that were entered to the database.