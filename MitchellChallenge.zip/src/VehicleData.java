import java.util.*;
import java.io.FileWriter;
import java.io.IOException;
public class VehicleData {
	
	//going to store all the vehicles
	private List<Vehicle> vehicleData = new ArrayList<Vehicle>();
	
	/**
	 * Description: returns all the vehicles
	 * @param None
	 * @return database of all the vehicles
	 */
	public List<Vehicle> allVehicles(){
		return vehicleData;
	}
	
	/**
	 * Description: Creates a new vehicle in the database
	 * Parameters: newVehicle - new vehicle to be added
	 * @return true if successfully added,else exits the program
	 */
	public void createVehicle(Vehicle newVehicle) {
		vehicleData.add(newVehicle);
	}
	
	/**
	 * Description: Creates a separate file by filtering based on ID 
	 * @param id - ID of the car
	 * @return None
	 */
	public void getById(int id, String file) {
		try {
			FileWriter dataFile = new FileWriter(file);
			dataFile.write("ID " + "Year " + "Make " + "Model\n");
			for(int i = 0; i < vehicleData.size(); i++) {
				String currModel = "";
				String currMake = "";
				//ensure model is not null
				if(vehicleData.get(i).getModel() != null) {
					currModel = vehicleData.get(i).getModel();
				}else {
					currModel = "null";
				}
				//ensure make is not null
				if(vehicleData.get(i).getMake() != null) {
					currMake = vehicleData.get(i).getMake();
				}else {
					currMake = "null";
				}
				if(vehicleData.get(i).getId() == id) {
					dataFile.write(Integer.toString(vehicleData.get(i).getId()) 
							+ " " + Integer.toString(vehicleData.get(i).getYear())
							+ " " + currMake + " " + currModel + "\n");
				}
			}
			dataFile.close();
		}catch(IOException e) {
			System.out.println("Error Occurred");
			System.exit(0);
		}
		
	}
	
	/**
	 * Description: Writes database to file
	 * Parameters: None
	 * @return true if successfully written to file
	 */
	public boolean getData(String file) {
		try {
			//open the file to read into
			FileWriter dataFile = new FileWriter(file);
			dataFile.write("ID " + "Year " + "Make " + "Model\n");
			//write all of the vehicles 
			for(int i = 0; i < vehicleData.size(); i++) {
				String currModel = "";
				String currMake = "";
				//ensure model is not null
				if(vehicleData.get(i).getModel() != null) {
					currModel = vehicleData.get(i).getModel();
				}else {
					currModel = "null";
				}
				//ensure make is not null
				if(vehicleData.get(i).getMake() != null) {
					currMake = vehicleData.get(i).getMake();
				}else {
					currMake = "null";
				}
				dataFile.write(Integer.toString(vehicleData.get(i).getId()) 
						+ " " + Integer.toString(vehicleData.get(i).getYear()) 
						+ " " + currMake + " " + currModel + "\n");
			}
			//close the file we have just written into
			dataFile.close();
		}catch(IOException e) {
			System.out.println("Error Occurred");
			System.exit(0);
		}
		return true;
	}
	
	/**
	 * Description: updating ID based given a vehicle
	 * @param newId - the new ID of the vehicle 
	 * @param vehicle - vehicle to add the new vehicle
	 * @return None
	 */
	public void updateId(int newId, Vehicle vehicle) {
		for(int i = 0; i < vehicleData.size(); i++) {
			if(vehicleData.get(i) == vehicle) {
				vehicleData.get(i).setId(newId);
				break;
			}
		}
	}
	
	/**
	 * Description: updating year based given a vehicle
	 * @param year - the updated year to be added
	 * @param vehicle - the vehicle to add the updated year to
	 * @return None
	 */
	public void updateYear(int year, Vehicle vehicle) {
		for(int i = 0; i < vehicleData.size(); i++) {
			if(vehicleData.get(i) == vehicle) {
				vehicleData.get(i).setYear(year);
				break;
			}
		}
	}
	
	/**
	 * Description: updating the make based given a vehicle
	 * @param newMake - the updated make of the car
	 * @param vehicle - the vehicle to add the updated year to
	 * @return None
	 */
	public void updateMake(String newMake, Vehicle vehicle) {
		for(int i = 0; i < vehicleData.size(); i++) {
			if(vehicleData.get(i) == vehicle) {
				vehicleData.get(i).setMake(newMake);
				break;
			}
		}
	}
	
	/**
	 * Description: updating the make based given a vehicle
	 * @param newModel - the updated model of the car
	 * @param vehicle - the vehicle to add the updated year to
	 * @return None
	 */
	public void updateModel(String newModel, Vehicle vehicle) {
		for(int i = 0; i < vehicleData.size(); i++) {
			if(vehicleData.get(i) == vehicle) {
				vehicleData.get(i).setModel(newModel);
				break;
			}
		}
	}
	
	/**
	 * Description: deletes the first car that has the following properties as vehicles
	 * @param vehicle - the vehicle to delete
	 * @return None
	 */
	public void deleteCar(Vehicle vehicle) {
		vehicleData.remove(vehicle);
	}
	
	/**
	 * Description: deletes all the cars that have similar IDs
	 * @param id - cars with this id to delete
	 * @return None
	 */
	public void deleteById(int id) {
		for(int i = 0; i < vehicleData.size(); i++) {
			if(vehicleData.get(i).getId() == id) {
				vehicleData.remove(i);
			}
		}
	}
	
//----------------------optional part of assignment below ---------------------------
	
	
	/**
	 * Description: gets all the cars by a specific year and ensures that make and model
	 * are not null
	 * @param startYear - the beginning of the desired range of year
	 * @param endYear - the end of the desired range of year
	 */
	public void getByYear(int startYear, int endYear, String file) {
		if(startYear > endYear) {
			return;
		}
		try {
			FileWriter dataFile = new FileWriter(file);
			dataFile.write("ID " + "Year " + "Make " + "Model\n");
			for(int i = 0; i < vehicleData.size(); i++) {
				if(vehicleData.get(i).getYear() >= startYear && 
						vehicleData.get(i).getYear() <= endYear && 
						vehicleData.get(i).getMake() != null &&
						vehicleData.get(i).getModel() != null) {
					
					dataFile.write(Integer.toString(vehicleData.get(i).getId()) 
							+ " " + Integer.toString(vehicleData.get(i).getYear()) 
							+ " " + vehicleData.get(i).getMake() + " " + 
							vehicleData.get(i).getModel() + "\n");
				}
			}
			dataFile.close();
		}catch(IOException e) {
			System.out.println("Error Occurred");
			System.exit(0);
		}
	}
	
}
