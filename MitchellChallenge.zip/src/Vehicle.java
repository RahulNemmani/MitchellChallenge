public class Vehicle {
	private int id = 0; 
	private int year = 0;
	private String make = null;
	private String model = null;
	
	/**
	 * Description: Constructs a Vehicle Object
	 * Parameters: id - id of the vehicle
	 * 			   year - year the vehicle was built
	 *             make - company that made the vehicle
	 *             model - model of the vehicle
	 * @return the id of the vehicle; if zero, then not documented
	 */
	public Vehicle(int id, int year, String make, String model) {
		this.id = id;
		this.year = year;
		this.make = make;
		this.model = model;
	}
	
	/**
	 * Description: returns the ID of a particular vehicle
	 * Parameters: None
	 * @return the id of the vehicle; if zero, then not documented
	 */
	public int getId() {
		return id;
	}
	
	/**
	 * Description: sets the ID of a new vehicle
	 * Parameters: id: the new ID of the vehicle
	 * @return None
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	/**
	 * Description: returns the year of a particular vehicle
	 * Parameters: None
	 * @return the year of the vehicle; if zero, then not documented
	 */
	public int getYear() {
		return this.year;
	}
	
	/**
	 * Description: sets the year of a new vehicle
	 * Parameters: year: the new year of the vehicle
	 * @return None
	 */
	public void setYear(int year) {
		this.year = year;
	}
	
	/**
	 * Description: returns who made the vehicle
	 * Parameters: None
	 * @return who made the car; if null, then says cannot be found
	 */
	public String getMake() {
		if(this.make == null) {
			return "Not found";
		}else {
			return this.make;
		}
	}
	
	/**
	 * Description: sets who made the model
	 * Parameters: newMake: the company who made the vehicle
	 * @return None
	 */
	public void setMake(String newMake) {
		this.make = newMake;
	}
	
	/**
	 * Description: gets the model of the vehicle
	 * Parameters: None
	 * @return if model is null, then "Not found" else the model of car
	 */
	public String getModel() {
		if(this.model == null) {
			return "Not found";
		}else {
			return model;
		}
	}
	
	/**
	 * Description: sets the model of a new vehicle
	 * Parameters: newModel: the new model of the vehicle
	 * @return None
	 */
	public void setModel(String newModel) {
		this.model = newModel;
	}
}
