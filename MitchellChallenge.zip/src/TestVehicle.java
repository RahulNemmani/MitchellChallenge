import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestVehicle {

	@Test
	void ensureGettersTestOfVehicleClassWorks() {
		Vehicle newVehicle = new Vehicle(20,2006,"Toyota","Prius");
		assertEquals("Toyota", newVehicle.getMake());
		assertEquals(2006, newVehicle.getYear());
		assertEquals(20, newVehicle.getId());
		assertEquals("Prius", newVehicle.getModel());
	}
	
	@Test
	void settersTestVehicles() {
		Vehicle currVehicle = new Vehicle(21,2006, "Nissan", "Centra");
		currVehicle.setId(34);
		assertEquals(34,currVehicle.getId());
		currVehicle.setMake("Honda");
		assertEquals("Honda",currVehicle.getMake());
		currVehicle.setModel("Civic");
		assertEquals("Civic",currVehicle.getModel());
		currVehicle.setYear(2010);
		assertEquals(2010, currVehicle.getYear());
	}
	
	@Test
	void testExceptionsGettersSetters() {
		Vehicle currVehicle = new Vehicle(0,0,null,null);
		assertEquals("Not found", currVehicle.getMake());
		assertEquals(0,currVehicle.getYear());
		assertEquals(0,currVehicle.getId());
		assertEquals("Not found", currVehicle.getModel());
	}
	
	@Test
	void writingToFile() {
		VehicleData database = new VehicleData();
		Vehicle newVehicle = new Vehicle(21,2006, "Nissan", "Centra");
		database.createVehicle(newVehicle);
		Vehicle anotherVehicle = new Vehicle(23,2019, "Honda", "Civic");
		database.createVehicle(anotherVehicle);
		String fileName = "vehicleData.txt";
		assertEquals(true, database.getData(fileName));
	}
	
	@Test
	void filterById() {
		VehicleData vehicles = new VehicleData();
		for(int i = 0; i < 120; i++) {
			if(i % 2 == 0) {
				vehicles.allVehicles().add(new Vehicle(50, 2000 + i, "Nissan", "Centra"));
			}else {
				vehicles.allVehicles().add(new Vehicle(51,2000 + i,"Honda", "Civic"));
			}
		}
		String fileName = "filterById.txt";
		vehicles.getById(50,fileName);
		String file = "test.txt";
		vehicles.getByYear(1990, 2100, file);
	}
	
	@Test
	void testUpdate() {
		Vehicle vehicle = new Vehicle(20,2001,"Honda","Civic");
		VehicleData data = new VehicleData();
		data.createVehicle(vehicle);
		data.updateId(21, vehicle);
		assertEquals(vehicle.getId(),21);
	}
	
	@Test
	void testDelete() {
		VehicleData data = new VehicleData();
		for(int i = 0; i < 150; i++) {
			data.createVehicle(new Vehicle(i,2019,"Nissan", "Centra"));
		}
		data.deleteById(100);
		data.getData("deleteFile.txt");
	}

}
